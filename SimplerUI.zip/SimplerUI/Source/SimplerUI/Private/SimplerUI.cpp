// Copyright Epic Games, Inc. All Rights Reserved.

#include "SimplerUI.h"
#include "Core.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FSimplerUIModule, SimplerUI)

void FSimplerUIModule::StartupModule()
{
	
}

void FSimplerUIModule::ShutdownModule()
{
	
}


	
